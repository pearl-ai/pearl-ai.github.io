import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from sys import exit

import mdp_utils
mpl.rcParams['toolbar'] = 'None'

PLOT_BACKGROUND_COLOR = '#99ccff'

STATE_COLOR = '#ff9933'
STATE_SELECT_COLOR = 'k'
STATE_UPDATE_COLOR = 'k'
STATE_UNVISITED_COLOR = '1.0'
STATE_VISIT_UPDATE_COLOR = STATE_SELECT_COLOR

ACTION_COLOR = '#ee66ee'
ACTION_SELECT_COLOR = 'k'
ACTION_UPDATE_COLOR = 'k'
ACTION_UNVISITED_COLOR = '1.0'
ACTION_VISIT_UPDATE_COLOR = ACTION_SELECT_COLOR

STATE_ACTION_ARROW_COLOR = '0.4'
STATE_ACTION_ARROW_SELECT_COLOR = '0.2'
ACTION_STATE_ARROW_COLOR = '#ccffff'

STATE_RADIUS = 0.5
ACTION_RADIUS = 0.35

STATE_NAME_FONT_COLOR = 'k'
STATE_NAME_FONT_SIZE = 12
STATE_VALUE_FONT_COLOR = '#000099'
STATE_VALUE_FONT_SIZE = 12
STATE_UPDATE_FONT_COLOR = '#ccffff'
STATE_SELECT_FONT_COLOR = '#ccffff'

ACTION_NAME_FONT_COLOR = 'k'
ACTION_NAME_FONT_SIZE = 10
ACTION_VALUE_FONT_COLOR = '#000099'
ACTION_VALUE_FONT_SIZE = 8
ACTION_UPDATE_FONT_COLOR = '#ccffff'
ACTION_SELECT_FONT_COLOR = '#ccffff'

PROBABILITY_FONT_COLOR = 'k'
PROBABILITY_FONT_SIZE = 10

POSITIVE_REWARD_COLOR = 'g'
NEGATIVE_REWARD_COLOR = 'r'
REWARD_FONT_SIZE = 10

WINDOW_MESSAGE_COLOR = 'g'
PAUSE_TIME = 0.5

class Extremes:
    MAX_POSITION = 1000000
    MIN_POSITION = -1000000

    def __init__(self):
        self.low_x = self.MAX_POSITION
        self.low_y = self.MAX_POSITION
        self.high_x = self.MIN_POSITION
        self.high_y = self.MIN_POSITION

    def set_value(self, low_x, low_y, high_x, high_y):
        self.low_x = low_x
        self.low_y = low_y
        self.high_x = high_x
        self.high_y = high_y

    def expand(self, low_x, low_y, high_x, high_y):
        if self.low_x > low_x:
            self.low_x = low_x
        if self.low_y > low_y:
            self.low_y = low_y
        if self.high_x < high_x:
            self.high_x = high_x
        if self.high_y < high_y:
            self.high_y = high_y

class GraphicElement:
    def __init__(self):
        self.extremes = Extremes()

    def pause(self, swift=False):
        if not swift:
            plt.pause(PAUSE_TIME)
        return self

class Window(GraphicElement):
    def __init__(self):
        self.fig, self.ax = plt.subplots()
        self.fig.set_facecolor(PLOT_BACKGROUND_COLOR)
        self.fig.set_size_inches(10, 6)
        self.ax.set_autoscale_on(False)
        self.ax.set_aspect(1)
        plt.box(on=None)
        plt.subplots_adjust(left=0.0, right=1.0, top=1.0, bottom=0.05)
        plt.setp(self.ax.get_xticklabels(), visible=False)
        plt.setp(self.ax.get_yticklabels(), visible=False)
        self.ax.tick_params(axis='both', which='both', length=0)
        self.ax.set_xlabel('')
        self.fig.canvas.mpl_connect('close_event', self.handle_close_event)
        self.ax.xaxis.label.set_color(WINDOW_MESSAGE_COLOR)
        # plt.get_current_fig_manager().frame.Maximize(True)
        plt.get_current_fig_manager().window.showMaximized()
        super().__init__()

    def handle_close_event(self, event):
        self.fig, self.ax = None, None
        print("Window Closed.")
        exit(0)

    def set_limits(self, xlims=None, ylims=None):
        if xlims != None:
            plt.xlim(xlims[0], xlims[1])
        if ylims != None:
            plt.ylim(ylims[0], ylims[1])
        if xlims==None and ylims==None:
            plt.xlim(self.extremes.low_x, self.extremes.high_x)
            plt.ylim(self.extremes.low_y, self.extremes.high_y)
        return self

    def include_shape(self, shape):
        # old_extremes = mdp_utils.float_strs(self.extremes.low_x, self.extremes.low_y, self.extremes.high_x, self.extremes.high_y)
        # new_extremes = mdp_utils.float_strs(shape.extremes.low_x, shape.extremes.low_y, shape.extremes.high_x, shape.extremes.high_y)
        # print("Expanding Window from", old_extremes, "\n", " "*17, "to", new_extremes)
        low_x = shape.extremes.low_x
        low_y = shape.extremes.low_y
        high_x = shape.extremes.high_x
        high_y = shape.extremes.high_y
        self.extremes.expand(low_x, low_y, high_x, high_y)

    def update_message(self, message=''):
        self.ax.set_xlabel(message)
        return self

class CircleProperties:
    def __init__(self, radius, color, name_size, name_color, text_size, text_color, update_color, update_font_color, select_color, select_font_color, unvisit_color, unvisit_font_color):
        self.radius = radius
        self.color = color
        self.name_size = name_size
        self.name_color = name_color
        self.text_size = text_size
        self.text_color = text_color
        self.update_color = update_color
        self.update_font_color = update_font_color
        self.select_color = select_color
        self.select_font_color = select_font_color
        self.unvisit_color = unvisit_color
        self.unvisit_font_color = unvisit_font_color

class MdpCircle(GraphicElement):
    def __init__(self, name, text, position, relative_name_position, properties, window):
        super().__init__()
        # check strings
        self.name = name
        # self.position = position
        # self.name_position = name_position
        self.properties = properties
        self.patch = mpatches.Circle(
            # self.position, # if declared above
            position, 
            radius=self.properties.radius, 
            color=self.properties.color, 
            alpha=0.8)
        window.ax.add_artist(self.patch)
        self.name_annotation = window.ax.annotate(
            name, 
            # self.name_position, 
            mdp_utils.add_car_to_pol(position, relative_name_position), 
            # name_position=mdp_utils.add_car_to_pol(position, relative_name_position), 
            fontsize=self.properties.name_size, 
            color=self.properties.name_color, 
            ha='center', 
            va='center',
            )
        self.text_annotation = window.ax.annotate(
            text, 
            # self.position, 
            position, 
            fontsize=self.properties.text_size, 
            color=self.properties.text_color, 
            ha='center', 
            va='center',
            )
        radius = relative_name_position[0]

        # low_x = position[0]-2*radius
        # low_y = position[1]-2*radius
        # high_x = position[0]+2*radius
        # high_y = position[1]+2*radius
        # new_extremes = mdp_utils.float_strs(low_x, low_y, high_x, high_y)
        # position_str = mdp_utils.float_strs(position[0], position[1])
        # radius_str = mdp_utils.float_str(radius)
        # print("setting extremes of", name, "to", new_extremes, "having position", position_str, "and radius", radius_str)

        self.extremes.set_value(
            low_x = position[0]-2*radius, 
            low_y = position[1]-2*radius, 
            high_x = position[0]+2*radius, 
            high_y = position[1]+2*radius,
            )

        window.include_shape(self)
        if text == None:
            self.name_annotation.set_text("")
            self.text_annotation.set_text(self.name)

    def color(self):
        return self.patch.get_facecolor()

    def font_color(self):
        return self.text_annotation.get_color()

    def colors(self):
        return self.color(), self.font_color()

    def position(self):
        return self.patch.center

    def set_colors(self, color, font_color=None):
        self.patch.set_color(color)
        if font_color:
            self.text_annotation.set_color(font_color)
        return self

    # def set_circle_color(self, color):
    #     self.patch.set_color(color)
    #     return self

    # def set_font_colors(self, font_color=None):
    #     self.text_annotation.set_color(font_color)
    #     return self

    def save_color(self):
        self._old_color, self._old_font_color = self.colors()
        return self

    def set_saved_color(self):
        self.set_colors(self._old_color, self._old_font_color)
        del self._old_color
        del self._old_font_color
        return self

    def set_text(self, text):
        if self.name_annotation.get_text() == "": # in the constructor
            self.name_annotation.set_text(self.name)
        self.text_annotation.set_text(text)
        return self

    def set_value(self, value):
        self.set_text(mdp_utils.float_str(value))
        return self

    def set_update_color(self):
        self.set_colors(self.properties.update_color, self.properties.update_font_color)
        return self

    # def set_update_circle_color(self):
    #     self.set_circle_color(self.properties.update_color)
    #     return self

    # def set_update_font_color(self):
    #     self.set_font_colors(self.properties.update_font_color)
    #     return self

    def set_select_color(self):
        self.set_colors(self.properties.select_color, self.properties.select_font_color)
        return self

    def set_unvisit_color(self):
        self.set_colors(self.properties.unvisit_color, self.properties.unvisit_font_color)
        return self

    def reset_color(self):
        self.set_colors(self.properties.color, self.properties.text_color)
        return self

    # def update_value(self, value, swift=False):
    #     self.set_text(mdp_utils.float_str(value)).save_color().set_update_color().pause(swift).set_saved_color().pause(swift)
    #     return self

    # def visit(self, swift=False):
    #     self.set_select_color().pause(swift).reset_color().pause(swift)


class StateCircle(MdpCircle):
    def __init__(self, name, value, position, relative_name_position, window):
        state_properties = CircleProperties(
            radius=STATE_RADIUS, 
            color=STATE_COLOR, 
            name_size=STATE_NAME_FONT_SIZE, 
            name_color=STATE_NAME_FONT_COLOR, 
            text_size=STATE_VALUE_FONT_SIZE, 
            text_color=STATE_VALUE_FONT_COLOR, 
            update_color=STATE_UPDATE_COLOR, 
            update_font_color=STATE_UPDATE_FONT_COLOR, 
            select_color=STATE_SELECT_COLOR, 
            select_font_color=STATE_SELECT_FONT_COLOR, 
            unvisit_color=STATE_UNVISITED_COLOR, 
            unvisit_font_color=None)
        text = mdp_utils.float_str(value)
        super().__init__(name, text, position, relative_name_position, state_properties, window)

class ActionCircle(MdpCircle):
    def __init__(self, name, value, state_circle, relative_position, relative_name_position, window):
        action_properties = CircleProperties(
            radius=ACTION_RADIUS, 
            color=ACTION_COLOR, 
            name_size=ACTION_NAME_FONT_SIZE, 
            name_color=ACTION_NAME_FONT_COLOR, 
            text_size=ACTION_VALUE_FONT_SIZE, 
            text_color=ACTION_VALUE_FONT_COLOR, 
            update_color=ACTION_UPDATE_COLOR, 
            update_font_color=ACTION_UPDATE_FONT_COLOR, 
            select_color=ACTION_SELECT_COLOR, 
            select_font_color=ACTION_SELECT_FONT_COLOR, 
            unvisit_color=ACTION_UNVISITED_COLOR, 
            unvisit_font_color=None)
        text = mdp_utils.float_str(value)
        position = mdp_utils.add_car_to_car(state_circle.position(), relative_position)
        super().__init__(name, text, position, relative_name_position, action_properties, window)

class MdpArrow(GraphicElement):
    def __init__(self, mdp_circle1, mdp_circle2, curvature, color, window):
        super().__init__()
        self.name = mdp_circle1.name + "-" + mdp_circle2.name + "-arrow"
        self.arrow = window.ax.annotate("", xy=mdp_circle2.position(), xytext=mdp_circle1.position(),
                    arrowprops=dict(arrowstyle=self.style(),
                                    color=color,
                                    patchA=mdp_circle1.patch,
                                    patchB=mdp_circle2.patch,
                                    shrinkA=10,
                                    shrinkB=10,
                                    connectionstyle="arc3,rad="+str(curvature),
                                    ),
                    )

    def style(self, wide=False):
        wide_style = "simple, tail_width=0.3, head_width=0.9, head_length=0.75"
        narrow_style = "simple, tail_width=0.01, head_width=0.5, head_length=0.5"
        return wide_style if wide else narrow_style

class StateActionArrow(MdpArrow):
    def __init__(self, state_circle, action_circle, curvature, window):
        self.default_color = STATE_ACTION_ARROW_COLOR
        super().__init__(state_circle, action_circle, curvature, self.default_color, window)

    def set_wide(self, wide=True):
        self.arrow.arrow_patch.set_arrowstyle(self.style(wide=wide))
        plt.draw()
        return self

    def set_color(self, color):
        self.arrow.arrow_patch.set_color(color)
        plt.draw()
        return self

    def set_select_color(self):
        self.set_color(STATE_ACTION_ARROW_SELECT_COLOR)
        return self

    def reset_color(self):
        self.set_color(self.default_color)
        return self

    def update_width(self, thick=False):
        self.set_wide(thick)
        return self

class ActionStateArrow(MdpArrow):
    def __init__(self, action_circle, state_circle, curvature, probability, relative_probability_position, reward, relative_reward_position, window):
        color = ACTION_STATE_ARROW_COLOR
        super().__init__(action_circle, state_circle, curvature, color, window)

        probability = mdp_utils.float_str(probability)
        self.probability_position = mdp_utils.add_cars_to_pol(action_circle.position(), state_circle.position(), relative_probability_position)
        probability_radius = relative_probability_position[0]        
        self.extremes.expand(
            low_x = self.probability_position[0] - 2*probability_radius,
            low_y = self.probability_position[1] - 2*probability_radius,
            high_x = self.probability_position[0] + 2*probability_radius,
            high_y = self.probability_position[1] + 2*probability_radius,
            )
        window.ax.annotate(probability, self.probability_position, fontsize=PROBABILITY_FONT_SIZE, color=PROBABILITY_FONT_COLOR, ha='center', va='center')
        if float(reward) != 0 and relative_reward_position != None:
            reward = mdp_utils.float_str(reward)
            self.reward_position = mdp_utils.add_car_to_pol(self.probability_position, relative_reward_position)
            reward_radius = relative_reward_position[0]
            self.extremes.expand(
                low_x = self.reward_position[0] - 2*reward_radius,
                low_y = self.reward_position[1] - 2*reward_radius,
                high_x = self.reward_position[0] + 2*reward_radius,
                high_y = self.reward_position[1] + 2*reward_radius,
                )
            reward_color = NEGATIVE_REWARD_COLOR if reward[0] == "-" else POSITIVE_REWARD_COLOR
            window.ax.annotate(reward, self.reward_position ,fontsize=REWARD_FONT_SIZE, color=reward_color, ha='center', va='center')
        window.include_shape(self)

class MdpElementGroup(GraphicElement):
    def __init__(self):
        self.state_circles = set()
        self.action_circles = set()
        self.state_action_arrows = set()
        self.action_state_arrows = set()

    def add(self, mdp_element):
        if isinstance(mdp_element, StateCircle):
            self.state_circles.add(mdp_element)
        elif isinstance(mdp_element, ActionCircle):
            self.action_circles.add(mdp_element)
        elif isinstance(mdp_element, StateActionArrow):
            self.state_action_arrows.add(mdp_element)
        elif isinstance(mdp_element, ActionStateArrow):
            self.action_state_arrows.add(mdp_element)
        return self

    def remove(self, mdp_element):
        if isinstance(mdp_element, StateCircle):
            self.state_circles.remove(mdp_element)
        elif isinstance(mdp_element, ActionCircle):
            self.action_circles.remove(mdp_element)
        elif isinstance(mdp_element, StateActionArrow):
            self.state_action_arrows.remove(mdp_element)
        elif isinstance(mdp_element, ActionStateArrow):
            self.action_state_arrows.remove(mdp_element)
        return self

    def clear(self):
        self.state_circles.clear()
        self.action_circles.clear()
        self.state_action_arrows.clear()
        self.action_state_arrows.clear()
        return self

    def select(self):
        [state_circle.set_select_color() for state_circle in self.state_circles]
        [state_action_arrow.set_select_color() for state_action_arrow in self.state_action_arrows]
        [action_circle.set_select_color() for action_circle in self.action_circles]
        return self

    def deselect(self):
        [state_circle.reset_color() for state_circle in self.state_circles]
        [state_action_arrow.reset_color() for state_action_arrow in self.state_action_arrows]
        [action_circle.reset_color() for action_circle in self.action_circles]
        return self
