class MDP:
	def __init__(self):
		"""MDP is a '4-tuple' ==> (S, A, P, R)"""
		self.states = []
		self.actions = []
		self.env_probabilities = {}
		self.env_rewards = {}

		"""other useful properties"""
		self.next_states = {}
		self.graphic_properties = {}

	def tg_to_mdp(self, tg, graphics=True):#enable graphics
		self.graphics = graphics
		self.states = list(tg["states"].keys())
		self.actions = {state: list(tg["states"][state]["actions"].keys()) for state in tg["states"].keys()}
		# for state, state_info in tg["states"].items():
		# 	for action, action_info in state_info["actions"].items():
		# 		self.next_states[(state, action)] = list(action_info["next_states"].keys())
		# 		for next_state, next_state_info in action_info["next_states"].items():
		# 			self.env_probabilities[(state, action, next_state)] = next_state_info["probability"]
		# 			self.env_rewards[(state, action, next_state)] = next_state_info["reward"]
		for state, state_info in tg["states"].items():
			if self.graphics:
				self.graphic_properties[state] = state_info["graphic_properties"]
			for action, action_info in state_info["actions"].items():
				if self.graphics:
					self.graphic_properties[(state, action)] = action_info["graphic_properties"]
				self.next_states[(state, action)] = list(action_info["next_states"].keys())
				for next_state, next_state_info in action_info["next_states"].items():
					if self.graphics:
						print(state, action, next_state, next_state_info["graphic_properties"])
						self.graphic_properties[(state, action, next_state)] = next_state_info["graphic_properties"]
					self.env_probabilities[(state, action, next_state)] = next_state_info["probability"]
					self.env_rewards[(state, action, next_state)] = next_state_info["reward"]
