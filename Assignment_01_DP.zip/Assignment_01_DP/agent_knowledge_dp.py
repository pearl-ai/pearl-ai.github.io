import random
import environment_tg
from environment_mdp import MDP
import mdp_shapes

class AvailableInfo:
	def __init__(self, mdp):
		self.__policy = {}
		self.__gamma = 1
		self.__state_value = {} 	# maps state -> real number
		self.__action_value = {} # maps (state, action) -> real number
		for state in mdp.states:
			self.__state_value[state] = None
			for action in mdp.actions[state]:
				self.__action_value[(state, action)] = None
		self.__mdp = mdp
		self.__window = None

		if mdp.graphics:
			self.__window = mdp_shapes.Window()
			self.__state_circle = {}
			self.__action_circle = {}
			self.__state_action_arrow = {}
			self.__action_state_arrow = {}
			for state in self.__mdp.states:
				state_graphics = mdp.graphic_properties[state]
				state_properties = {
					"name": state,
					"value": self.__state_value[state],
					"position": state_graphics["position"],
					"relative_name_position": state_graphics["relative_name_position"],
					"window": self.__window
				}
				self.__state_circle[state] = mdp_shapes.StateCircle(**state_properties)
			for state in self.states():
				for action in self.actions(state):
					action_graphics = mdp.graphic_properties[(state, action)]
					action_properties = {
						"name": action,
						"value": self.__action_value[(state, action)],
						"state_circle": self.__state_circle[state],
						"relative_position": action_graphics["relative_position"],
						"relative_name_position": action_graphics["relative_name_position"],
						"window": self.__window,
					}
					self.__action_circle[(state, action)] = mdp_shapes.ActionCircle(**action_properties)
					state_action_properties = {
						"state_circle": self.__state_circle[state],
						"action_circle": self.__action_circle[(state, action)],
						"curvature": action_graphics["state_arrow_curvature"],
						"window": self.__window,
					}
					self.__state_action_arrow[(state, action)] = mdp_shapes.StateActionArrow(**state_action_properties)
					for next_state in self.__mdp.next_states[(state, action)]:
						next_state_graphics = mdp.graphic_properties[(state, action, next_state)]
						action_state_properties = {
							"action_circle": self.__action_circle[(state, action)],
							"state_circle": self.__state_circle[next_state],
							"curvature": next_state_graphics["action_arrow_curvature"],
							"probability": self.__mdp.env_probabilities[(state, action, next_state)],
							"relative_probability_position": next_state_graphics["relative_probability_position"],
							"reward": self.__mdp.env_rewards[(state, action, next_state)],
							"relative_reward_position": next_state_graphics["relative_reward_position"],
							"window": self.__window,
						}
						self.__action_state_arrow[(state, action, next_state)] = mdp_shapes.ActionStateArrow(**action_state_properties)
			self.__window.set_limits()

	def states(self):
		return self.__mdp.states
		
	def actions(self, state):
		return self.__mdp.actions[state]
		
	def next_states(self, state_action_pair):
		return self.__mdp.next_states[state_action_pair]

	def env_rewards(self):
		return self.__mdp.env_rewards

	def env_probabilities(self):
		return self.__mdp.env_probabilities
		
	def is_terminal(self, state):
		return False if len(self.__mdp.actions[state]) else True 
		
	def transistion_info(self, state, action, next_state):
		p = self.__mdp.env_probabilities[(state, action, next_state)]
		r = self.__mdp.env_rewards[(state, action, next_state)]
		v = self.__state_value[next_state]
		return (p, r, v)
		
	def value(self, node):
		if isinstance(node, str):
			return self.__state_value[node]
		elif isinstance(node, tuple) and len(node) == 2:
			return self.__action_value[node]
		
	def gamma(self):
		return self.__gamma
	
	def policy(self):
		return self.__policy

	def update_message(self, message):
		self.__window.update_message(message).pause()
		return self.__window

	def select_group(self, state):
		# if self.__window:
		# 	self.__state_circle[state].set_select_color()
		# 	for action in self.__mdp.actions[state]:
		# 		self.__action_circle[(state, action)].set_select_color()
		# 		self.__state_action_arrow[(state, action)].set_select_color()
		# 	self.__window.pause()
			return self.__window

	def deselect_group(self, state):
		# if self.__window:
		# 	self.__state_circle[state].reset_color()
		# 	for action in self.__mdp.actions[state]:
		# 		self.__action_circle[(state, action)].reset_color()
		# 		self.__state_action_arrow[(state, action)].reset_color()
		# 	self.__window.pause()
			return self.__window

	def update_policy(self, state, argmax_action):
		old_policy = self.__policy[state] if state in self.__policy else None
		new_policy = argmax_action
		self.__policy[state] = argmax_action

		if self.__window:
			self.select_group(state)
			if old_policy != new_policy:
				if old_policy:
					self.__state_action_arrow[(state, old_policy)].set_wide(False)
				self.__state_action_arrow[(state, new_policy)].set_wide().pause()
			self.deselect_group(state)
		
	def assign_policy(self, state, argmax_action):
		old_policy = self.__policy[state] if state in self.__policy else None
		new_policy = argmax_action
		self.__policy[state] = argmax_action

		if self.__window:
			if old_policy != new_policy:
				if old_policy:
					self.__state_action_arrow[(state, old_policy)].set_wide(False)
				self.__state_action_arrow[(state, new_policy)].set_wide()
		
	def update_state_value(self, state, value):
		self.__state_value[state] = value
		if self.__window:
			self.select_group(state)
			# self.__state_circle[state].set_select_color().pause()
			# self.__state_circle[state].set_value(self.__state_value[state]).set_update_circle_color().pause().set_update_font_color().pause()
			self.__state_circle[state].set_update_color().pause().set_value(self.__state_value[state]).pause()
			self.__state_circle[state].reset_color().pause()
			self.deselect_group(state)

	def assign_state_value(self, state, value):
		self.__state_value[state] = value
		if self.__window:
			self.__state_circle[state].set_value(self.__state_value[state])

	def update_action_value(self, state_action_pair, value):
		self.__action_value[state_action_pair] = value
		(state, action) = state_action_pair
		if self.__window:
			self.select_group(state)
			self.__action_circle[(state, action)].set_value(self.__action_value[state_action_pair]).set_update_color().pause()
			# self.__action_circle[(state, action)].set_select_color().pause()
			self.__action_circle[(state, action)].reset_color().pause()
			self.deselect_group(state)

	def assign_action_value(self, state_action_pair, value):
		self.__action_value[state_action_pair] = value
		(state, action) = state_action_pair
		if self.__window:
			self.__action_circle[(state, action)].set_value(self.__action_value[state_action_pair])

	def randomise_policy(self):
		old_policy = self.__policy
		for state in self.__mdp.states:
			action_choices = self.actions(state)
			if action_choices:
				policy_action = random.choice(action_choices)
				self.assign_policy(state, policy_action)

	def set_state_values_to_zero(self):
		for state in self.__mdp.states:
			self.assign_state_value(state, 0)

	def set_action_values_to_zero(self):
		for state, action in self.__state_action_pairs:
			self.assign_action_value((state, action), 0)

	def randomise_state_values(self):
		for state in self.__mdp.states:
			self.assign_state_value(state, random.random())
	
	def randomise_action_values(self):
		for state, action in self.__state_action_pairs:
			self.assign_action_value((state, action), random.random())



	# def update_policy(self, state, argmax_action):
	# 	self.__policy[state] = argmax_action
		
	# def update_state_value(self, state, value):
	# 	self.__state_value[state] = value
		
	# def update_action_value(self, state_action_pair, value):
	# 	self.__action_value[state_action_pair] = value

	# def randomise_policy(self):
	# 	for state in self.__mdp.states():
	# 		action_choices = self.__mdp.actions(state)
	# 		if action_choices:
	# 			self.__policy[state] = random.choice(action_choices)

	# def randomise_state_values(self):
	# 	for state in self.__mdp.states():
	# 		self.update_state_value(state, random.random())
	
	# def randomise_action_values(self):
	# 	for state, action in self.__state_action_pairs:
	# 		self.update_action_value((state, action), random.random())

if __name__ == "__main__":
	mdp = MDP()
	mdp.tg_to_mdp(environment_tg.small_tg)
	available_info = AvailableInfo(mdp)
