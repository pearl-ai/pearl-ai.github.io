from environment_mdp import MDP
from agent_knowledge_dp import AvailableInfo
import environment_tg
import numpy as np

def expected_value(state, action, available_info):
	expected_value = 0
	gamma = available_info.gamma()
	for next_state in available_info.next_states((state, action)):
		p, r, v = available_info.transistion_info(state, action, next_state)
		expected_value += p * (r + gamma*v)
	return expected_value
	
def argmax_action(state, available_info):
	best_action = None
	best_action_value = -float('Inf')
	for action in available_info.actions(state):
		exp_val = expected_value(state, action, available_info)
		if exp_val >= best_action_value:
			best_action = action
			best_action_value = exp_val
	return best_action
			
def policy_iteration(available_info):
	#initialisation
	tolerable_error = 0.01
	available_info.randomise_state_values()
	available_info.randomise_policy()

	# while True:
	for i in range(100):
		#policy evaluation
		available_info.update_message("Evaluating Policy")
		policy_stable = True
		while True:
			max_error = 0
			for state in available_info.states():
				if available_info.is_terminal(state):
					continue
				current_value = available_info.value(state)
				action = available_info.policy()[state]
				v = expected_value(state, action, available_info)
				available_info.update_state_value(state, v)
				max_error = max(max_error, abs(current_value - available_info.value(state)))
			if max_error < tolerable_error:
				break
		#policy improvement
		available_info.update_message("Improving Policy")
		for state in available_info.states():
			if available_info.is_terminal(state):
				continue
			old_best_action = available_info.policy()[state]
			available_info.update_policy(state, argmax_action(state, available_info))	
			if old_best_action != available_info.policy()[state]:
				policy_stable = False
		if policy_stable == True:
			break

if __name__ == "__main__":
	mdp = MDP()
	mdp.tg_to_mdp(environment_tg.small_tg)
	available_info = AvailableInfo(mdp) 
	policy_iteration(available_info)
	available_info.update_message("Ended Policy Iteration")
	print(available_info.policy())
