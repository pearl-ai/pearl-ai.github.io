import random
import numpy as np
import environment_tg
from environment_mdp import MDP
import mdp_shapes

class AvailableInfo:
	def __init__(self, mdp):
		self.__mdp = mdp
		self.__state_value = {} 	# maps state -> real number
		self.__action_value = {} # maps (state, action) -> real number
		for state in mdp.states:
			self.__state_value[state] = None
			for action in mdp.actions[state]:
				self.__action_value[(state, action)] = None
		self.__policy = {}
		self.__returns = {}
		self.__start_states = ['s0', 's1', 's3']
		
		self.__gamma = 1
		self.__epsilon = 0.1

		if mdp.graphics:
			self.__window = mdp_shapes.Window()
			self.__state_circle = {}
			self.__action_circle = {}
			self.__state_action_arrow = {}
			self.__action_state_arrow = {}
			for state in self.__mdp.states:
				state_graphics = mdp.graphic_properties[state]
				state_properties = {
					"name": state,
					"value": self.__state_value[state],
					"position": state_graphics["position"],
					"relative_name_position": state_graphics["relative_name_position"],
					"window": self.__window
				}
				self.__state_circle[state] = mdp_shapes.StateCircle(**state_properties)
			for state in self.__mdp.states:
				for action in self.__mdp.actions[state]:
					action_graphics = mdp.graphic_properties[(state, action)]
					action_properties = {
						"name": action,
						"value": self.__action_value[(state, action)],
						"state_circle": self.__state_circle[state],
						"relative_position": action_graphics["relative_position"],
						"relative_name_position": action_graphics["relative_name_position"],
						"window": self.__window,
					}
					self.__action_circle[(state, action)] = mdp_shapes.ActionCircle(**action_properties)
					state_action_properties = {
						"state_circle": self.__state_circle[state],
						"action_circle": self.__action_circle[(state, action)],
						"curvature": action_graphics["state_arrow_curvature"],
						"window": self.__window,
					}
					self.__state_action_arrow[(state, action)] = mdp_shapes.StateActionArrow(**state_action_properties)
					for next_state in self.__mdp.next_states[(state, action)]:
						next_state_graphics = mdp.graphic_properties[(state, action, next_state)]
						action_state_properties = {
							"action_circle": self.__action_circle[(state, action)],
							"state_circle": self.__state_circle[next_state],
							"curvature": next_state_graphics["action_arrow_curvature"],
							"probability": self.__mdp.env_probabilities[(state, action, next_state)],
							"relative_probability_position": next_state_graphics["relative_probability_position"],
							"reward": self.__mdp.env_rewards[(state, action, next_state)],
							"relative_reward_position": next_state_graphics["relative_reward_position"],
							"window": self.__window,
						}
						self.__action_state_arrow[(state, action, next_state)] = mdp_shapes.ActionStateArrow(**action_state_properties)
			self.__window.set_limits()

	def states(self):
		return self.__mdp.states
		
	def actions(self, state):
		return self.__mdp.actions[state]

	def is_terminal(self, state):
		return False if len(self.actions(state)) else True 
	
	def update_message(self, message):
		return self.__window.update_message(message)

	def pause(self):
		return self.__window.pause()

	def generate_sample_episode(self, policy):
		if self.__window:
			for state in self.states():
				self.__state_circle[state].set_unvisit_color()
				for action in self.actions(state):
					self.__action_circle[(state, action)].set_unvisit_color()
			self.pause()
		episode = []
		sampled_state = random.choice(self.__start_states)
		episode.append(sampled_state)
		if self.__window:
			self.__state_circle[sampled_state].set_select_color().pause().reset_color().pause()
		for i in range(10):
			current_state = sampled_state
			if not self.is_terminal(current_state):
				action_choices = self.actions(current_state)
				action_probabilities = [self.__policy[(current_state, action)] for action in self.actions(current_state)]
				sampled_action = np.random.choice(action_choices, 1, None, action_probabilities)[0]
				episode.append(sampled_action)
				if self.__window:
					self.__action_circle[(sampled_state, sampled_action)].set_select_color().pause().reset_color().pause()
				
				state_choices = self.__mdp.next_states[(current_state, sampled_action)]
				state_probabilities = [self.__mdp.env_probabilities[(current_state, sampled_action, state)] for state in state_choices]
				sampled_state = np.random.choice(state_choices, 1, None, state_probabilities)[0]
				episode.append(self.__mdp.env_rewards[(current_state, sampled_action, sampled_state)])
				episode.append(sampled_state)
				if self.__window:
					self.__state_circle[sampled_state].set_select_color().pause().reset_color().pause()
				
				if self.is_terminal(sampled_state):
					break
		print(episode)
		if self.__window:
			self.update_message("Ended Episode").pause()
		return episode

	def value(self, node):
		if isinstance(node, str):
			return self.__state_value[node]
		elif isinstance(node, tuple) and len(node) == 2:
			return self.__action_value[node]

	def gamma(self):
		return self.__gamma
	
	def policy(self):
		return self.__policy

	def set_policy(self, state, new_action):
		if self.__window:
			if not self.is_terminal(state):
				for action in self.actions(state):
					self.__state_action_arrow[(state, action)].set_wide(False)
				self.__state_action_arrow[(state, new_action)].set_wide()
			return self.__window

	def update_policy(self, state, argmax_action):
		if self.__window:
			self.update_message("Policy Update").pause()
			self.set_policy(state, argmax_action).pause()

		action_choices = self.actions(state)
		num_choices = len(action_choices)
		if num_choices:
			for action in self.actions(state):
				self.__policy[(state, action)] = self.__epsilon/num_choices
			self.__policy[(state, argmax_action)] += (1 - self.__epsilon)
		
	def update_state_value(self, state, value):
		self.__state_value[state] = value
		if self.__window:
			self.__state_circle[state].set_update_color().pause().set_value(self.__state_value[state]).pause()
			self.__state_circle[state].reset_color().pause()
		
	def update_action_value(self, state_action_pair, value):
		self.__action_value[state_action_pair] = value
		if self.__window:
			self.__action_circle[state_action_pair].set_update_color().pause().set_value(self.__action_value[state_action_pair]).pause()
			self.__action_circle[state_action_pair].reset_color().pause()

	def assign_action_value(self, state_action_pair, value):
		self.__action_value[state_action_pair] = value
		if self.__window:
			self.__action_circle[state_action_pair].set_value(self.__action_value[state_action_pair])

	def initialise_epsilon_soft_policy(self):
		for state in self.states():
			action_choices = self.actions(state)
			num_choices = len(action_choices)
			if num_choices:
				random_best_action = random.choice(action_choices)
				for action in self.actions(state):
					self.__policy[(state, action)] = self.__epsilon/num_choices
				self.__policy[(state, random_best_action)] += (1 - self.__epsilon)
				if self.__window:
					self.set_policy(state, random_best_action)
		self.__window.pause()

	def randomise_action_values(self):
		for state in self.states():
			for action in self.actions(state):
				# self.update_action_value((state, action), 10 + 10*random.random())
				self.assign_action_value((state, action), 10 + 10*random.random())

if __name__ == "__main__":
	mdp = MDP()
	mdp.tg_to_mdp(environment_tg.small_tg)
	available_info = AvailableInfo(mdp)
	# print(available_info._AvailableInfo__mdp)
	available_info.initialise_epsilon_soft_policy()
	available_info.generate_sample_episode(available_info.policy)