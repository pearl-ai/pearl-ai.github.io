small_tg = {
	"states": {
		"s0": {
			"graphic_properties": {
				"position": (7, 5),
				"relative_name_position": (0.8, -90),
			},
			"actions": {
				"a0": {
					"graphic_properties": {
						"state_arrow_curvature": 0,
						"relative_position": (-3, 0),
						"relative_name_position": (0.6, -90),
					},
					"next_states": {
						"s1": {
							"graphic_properties": {
								"action_arrow_curvature": 0,
								"relative_probability_position": (0.3, 0),
								"relative_reward_position": (0.6, 0),
							},
							"probability": 0.3,
							"reward": 5,
						},
						"s3": {
							"graphic_properties": {
								"action_arrow_curvature": 0,
								"relative_probability_position": (0.3, 0),
								"relative_reward_position": (0.6, 0),
							},
							"probability": 0.7,
							"reward": 3,
						},
					},
				},
				"a1": { 
					"graphic_properties": {
						"state_arrow_curvature": 0.3,
						"relative_position": (3, 0),
						"relative_name_position": (0.6, -90),
					},
					"next_states": {
						"s0": {
							"graphic_properties": {
								"action_arrow_curvature": 0.3,
								"relative_probability_position": (0.1, 0),
								"relative_reward_position": (0.5, 90),
							},
							"probability": 0.5,
							"reward": 7,
						},
						"s2": {
							"graphic_properties": {
								"action_arrow_curvature": 0,
								"relative_probability_position": (0.2, 90),
								"relative_reward_position": (0.4, -90),
							},
							"probability": 0.5,
							"reward": 8,
						},
					},
				},
			},
		},
		"s1": {
			"graphic_properties": {
				"position": (2, 2),
				"relative_name_position": (0.8, -135),
			},
			"actions": {
				"a2": {
					"graphic_properties": {
						"state_arrow_curvature": 0,
						# "relative_position": (3, 1),
						"relative_position": (6, 0),
						"relative_name_position": (0.6, -90),
					},
					"next_states": {
						"s2": {
							"graphic_properties": {
								"action_arrow_curvature": 0,
								"relative_probability_position": (0.2, 135),
								"relative_reward_position": (0.4, -45),
							},
							"probability": 1,
							"reward": 2,
						},
					},
				},
			},
		},
		"s2": {
			"graphic_properties": {
				"position": (13, 5),
				"relative_name_position": (0.8, 0),
			},
			"actions": {},
		},
		"s3": {
			"graphic_properties": {
				"position": (2, 8),
				"relative_name_position": (0.8, 135),
			},
			"actions": {
				"a0": {
					"graphic_properties": {
						"state_arrow_curvature": 0,
						# "relative_position": (3, -1),
						"relative_position": (6, 0),
						"relative_name_position": (0.6, -90),
					},
					"next_states": {
						"s2": {
							"graphic_properties": {
								"action_arrow_curvature": 0,
								"relative_probability_position": (0.2, -135),
								"relative_reward_position": (0.4, 45),
							},
							"probability": 1,
							"reward": 4,
						},
					},
				},
				"a3": {
					"graphic_properties": {
						"state_arrow_curvature": 0,
						"relative_position": (-2, -3),
						"relative_name_position": (0.6, -90),
					},
					"next_states": {
						"s1": {
							"graphic_properties": {
								"action_arrow_curvature": 0,
								"relative_probability_position": (-0.3, 0),
								"relative_reward_position": (0.6, 0),
							},
							"probability": 1,
							"reward": 6,
						},
					},
				},
			},
		},
	},
}
