from agent_knowledge_mc import AvailableInfo
import environment_tg
import numpy as np
from environment_mdp import MDP
import numpy as np
	
def argmax_action(state, available_info):
	best_action = None
	best_action_value = -float('Inf')
	for action in available_info.actions(state):
		exp_val = available_info.value((state, action))
		if exp_val >= best_action_value:
			best_action = action
			best_action_value = exp_val
	return best_action
			
def on_policy_monte_carlo_control(available_info):
	#initialisation
	tolerable_error = 0.01
	available_info.update_message("Randomized Action Values").pause()
	available_info.randomise_action_values()
	available_info.pause().pause().update_message("Initialized Epsilon Soft Policy").pause()
	available_info.initialise_epsilon_soft_policy()
	available_info.pause().pause()

	returns_history = {}

	# while True:
	for i in range(10):
		available_info.update_message("Generating Episode " + str(i))
		episode = available_info.generate_sample_episode(available_info.policy())
		G = 0 #return from end of episode
		episode = episode[0:-1]
		episode = list(zip(episode[0::3], episode[1::3], episode[2::3]))
		episode_returns = {}
		for state, action, reward in reversed(episode):
			G = reward + available_info.gamma()*G
			episode_returns[(state, action)] = G

		for state_action_pair, episode_return in episode_returns.items():
			if state_action_pair in returns_history:
				returns_history[state_action_pair].append(episode_return)
			else:
				returns_history[state_action_pair] = [episode_return]
			available_info.update_action_value(state_action_pair, np.mean(returns_history[(state_action_pair)]))

		for state in available_info.states():
			if available_info.is_terminal(state):
				continue
			available_info.update_policy(state, argmax_action(state, available_info))	
		print("episode", episode)
		print("returns_history", returns_history)
		print("policy", available_info.policy())

if __name__ == "__main__":
	mdp = MDP()
	mdp.tg_to_mdp(environment_tg.small_tg)
	available_info = AvailableInfo(mdp) 
	on_policy_monte_carlo_control(available_info)
