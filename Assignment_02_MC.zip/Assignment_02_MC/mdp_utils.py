from math import sin, cos, radians
import matplotlib.pyplot as plt
from numpy.random import choice
from random import random as rand, randrange

def pause(duration):
    plt.pause(duration)

def random(arg1=1, arg2=None):
    begin = 0 
    end = arg1
    if arg2 != None:
        begin = arg1
        end = arg2
    value = begin + rand()*(end-begin)
    return value

def choose(data):
    if isinstance(data, dict):
        for i,data_value in enumerate(data.values()):
            if not (isinstance(data_value, int) or isinstance(data_value, float)):
                raise TypeError("data values must be numeric, but value " + str(data_value) + " at index " + str(i) + "is found to be of type " + str(type(data_value)))
            if data_value < 0 or data_value > 1:
                raise ValueError("data value " + str(data_value) + " must lie between 0 and 1 (both inclusive) but value " + str(data_value) + " is found to be " + str(data_value))
        if sum(data.values()) != 1:
            raise ValueError("sum of data values must be 1, but is found to be " + str(sum(data.values())))
        draw = choice(list(data.keys()), p = list(data.values()))
        return draw

    elif isinstance(data, list):
        draw = choice(data)
        return draw

def choose2(data):
    if isinstance(data, dict):
        data_value = []
        distribution_prefix_sum = [0]
        for value, probability in data.items():
            data_value.append(value)
            distribution_prefix_sum.append(probability+distribution_prefix_sum[-1])
        assert(distribution_prefix_sum[-1] == 1), "Sum of probabilities must be 1 instead of "+str(distribution_prefix_sum[-1])+" in "+str(distribution_prefix_sum)
        r = rand()
        for i,probability in enumerate(distribution_prefix_sum):
            if distribution_prefix_sum[i] > r:
                return data_value[i-1]
        # draw = choice(list(data.keys()), 1, p = list(data.values()))
        # return draw[0]
        # draw = choice(list(data.keys()), p = list(data.values()))
        # return draw

    elif isinstance(data, list):
        index = randrange(len(data))
        return data[index]
        # draw = choice(data)
        # # print(type(draw), draw)
        # return draw

def float_str(x):
    if x == None:
        return None
    if abs(x) >= 100:
        return "{:.0e}".format(x)
    return "{:.2f}".format(x)

def float_strs(*args):
    return list(map(float_str, args))

def add_car_to_car(pos, rel):
    x = pos[0] + rel[0]
    y = pos[1] + rel[1]
    return (x, y)

def add_car_to_pol(pos, shift):
    x = pos[0] + shift[0]*cos(radians(shift[1]))
    y = pos[1] + shift[0]*sin(radians(shift[1]))
    return (x, y)

def add_cars_to_pol(pos1, pos2, shift):
    x = (pos1[0]+pos2[0])/2 + shift[0]*cos(radians(shift[1]))
    y = (pos1[1]+pos2[1])/2 + shift[0]*sin(radians(shift[1]))
    return (x, y)

def check_string(value, value_description="", override_string=None):
    error_string = ""
    if override_string != None:
        if not isinstance(override_string, str):
            raise TypeError("override string should be a string instead of " + str(type(override_string)))
    if value_description != "":
        if not isinstance(value_description, str):
            raise TypeError("value description should be a string instead of " + str(type(value_description)))
    if not isinstance(value, str):
        if override_string != None:
            error_string = override_string
        elif value_description != "":
            error_string = value_description + " must be a string instead of " + str(type(value))
        else:
            error_string = "value " + str(value) + " must be a string instead of " + str(type(value))
        raise TypeError(error_string)

def check_number(value, value_description="", override_string=None):
    check_string("", value_description, override_string)
    if not (isinstance(value, int) or isinstance(value, float)):
        error_string = ""
        if override_string != None:
            error_string = override_string
        elif value_description == "":
            error_string = value_description + " must be a number instead of " + str(type(value))
        else:
            error_string = "value" + str(value) + " must be a number instead of " + str(type(value))
        raise TypeError(error_string)

def check_number_in_range_0_to_1_both_included(value, value_description="", override_string=None):
    check_string("", value_description, override_string)
    check_number(value)
    if not 0 <= value <= 1:
        error_string = ""
        if override_string != None:
            error_string = override_string
        elif value_description == "":
            error_string = value_description + " must lie between 0 and 1 (both inclusive) instead of " + str(value)
        else:
            error_string = "value" + str(value) + " must lie between 0 and 1 (both inclusive) instead of " + str(value)
        raise TypeError(error_string)

def save_as_png(path_name='/home/shashwat/Desktop', file_name='last_plot'):
    # plt.savefig(path_name+file_name+'.png')
    plt.savefig(path_name+file_name+'.png')

def comments():
    # def float_str(x):
    #     if abs(x) >= 100:
    #         return "{:.0e}".format(x)
    #     return "{:.2f}".format(x)

    # def add_car_to_car(pos, rel):
    #     x = pos[0] + rel[0]
    #     y = pos[1] + rel[1]
    #     return (x, y)

    # def add_car_to_pol(pos, shift):
    #     x = pos[0] + shift[0]*cos(radians(shift[1]))
    #     y = pos[1] + shift[0]*sin(radians(shift[1]))
    #     return (x, y)

    # def add_cars_to_pol(pos1, pos2, shift):
    #     x = (pos1[0]+pos2[0])/2 + shift[0]*cos(radians(shift[1]))
    #     y = (pos1[1]+pos2[1])/2 + shift[0]*sin(radians(shift[1]))
    #     return (x, y)

    # stop_loop = False
    # def key_press_event_callback(event):
    # #     if not event.inaxes:
    # #         return
    # #     if event.key == 'q':
    #     if event.key == 'control':
    # #         event.key = 'q'
    # #         global stop_loop
    # #         stop_loop = True
    # #         print(stop_loop)
    #         plt.close()
    #         print("plt closed")
    #         sys.exit()
    # fig.canvas.mpl_connect('key_press_event', key_press_event_callback)
    return

if __name__ == "__main__":

    # distribution = [0.1, 0.3, 0.5, 0.1]
    distribution = {'a':0.1, 'b':0.3, 'c':0.5, 'd':0.1}
    # distribution = {0.1:'a', 0.3:'b', 0.5:'c', 0.1:'d'}
    # distribution = ['a', 'b', 'c', 'd']
    # distribution = [3, 6, 9, 12]
    freq = [0]*4
    # draw = []
    cnt = dict()
    for x in distribution:
        cnt[x] = 0
    for _ in range(1000):
        x = choose(distribution)
        cnt[x] += 1
        # freq[draw] += 1
    # print(freq)
    print(cnt)

    # print("ooo", isinstance(0, float))

    # distribution = [0.1, 0.3, 0.5, 0.1]
    # distribution = {'a':0.1, 'b':0.3, 'c':0.5, 'd':0.1}
    # cnt = dict()
    # draw = choose2(distribution)
    # print(draw)
    # for x in distribution:
    #     cnt[x] = 0
    # for x in draw:
    #     cnt[x] += 1
    # print("ch2", cnt)
    rvals = []
    for _ in range(10000):
        rvals.append(random(5, -2))
    print(sum(rvals)/len(rvals))